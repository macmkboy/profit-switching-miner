export GPU_MAX_ALLOC_PERCENT=100
export GPU_SINGLE_ALLOC_PERCENT=100
export GPU_MAX_HEAP_SIZE=100
export GPU_USE_SYNC_OBJECTS=1
./c3miner -p=mine.c3pool.com:19999 -u=YOUR_WALLET_ADDRESS --pass=`uname -n`:my@email.com --cn/r="./teamredminer -a cnr -o stratum+tcp://localhost:3333 -u x -p x" --cn/half="./teamredminer -a cnv8_half  -o stratum+tcp://localhost:3333 -u x -p x" --cn/double="./teamredminer -a cnv8_dbl  -o stratum+tcp://localhost:3333 -u x -p x" --cn/rwz="./teamredminer -a cnv8_rwz  -o stratum+tcp://localhost:3333 -u x -p x" --cn-pico/trtl="./teamredminer -a cnv8_trtl  -o stratum+tcp://localhost:3333 -u x -p x"