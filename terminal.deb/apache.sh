#!/bin/bash

sudo apache

exit 0